# Streamlit Invoice Extractor (Sciex)
This repository provides a Streamlit frontend to upload multiple PDF invoices, extract fields using rules for Novanta, Cronologic, and Mace invoice formats, and download the results as Excel or CSV.
## Files
- `app.py` — Main Streamlit application.
- `requirements.txt` — Python dependencies.
## How to deploy
1. Push this repo to GitHub.
2. Go to Streamlit Community Cloud (https://streamlit.io/cloud) and create a new app pointing to this repo and `app.py`.
3. Streamlit will install dependencies and run the app.
## Notes
- Choose the correct customer type in the sidebar before processing.
- The extractor uses regex patterns — if your PDFs have different layouts, adjust patterns in `app.py`.
